const namaInput = document.getElementById("nama");
const kirimBtn = document.getElementById("kirim");
const message = document.getElementById("message");
const daftar = document.getElementById("daftar");
const jumlah = document.getElementById("jumlah");
const tanggalEl = document.getElementById("tanggal");
const jamEl = document.getElementById("jam");
const hariEl = document.getElementById("hari");
const hapusBtn = document.getElementById("hapus");

let selectedStatus = null;

const statusButtons = document.querySelectorAll(".attendance");
statusButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    statusButtons.forEach(b => b.classList.remove("selected"));
    btn.classList.add("selected");
    selectedStatus = btn.dataset.status;
  });
});

// Waktu Indonesia Barat (UTC+7), otomatis berubah setiap detik.
function getWIBDate() {
  const now = new Date();
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  return new Date(utc + 7 * 60 * 60000);
}

function pad(n) {
  return String(n).padStart(2, "0");
}

function getDateKey(date) {
  return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}`;
}

function formatDate(date) {
  return new Intl.DateTimeFormat("id-ID", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric"
  }).format(date);
}

function updateClock() {
  const wib = getWIBDate();
  tanggalEl.textContent = formatDate(wib);
  jamEl.textContent = `${pad(wib.getHours())}:${pad(wib.getMinutes())}:${pad(wib.getSeconds())} WIB`;
  hariEl.textContent = new Intl.DateTimeFormat("id-ID", { weekday: "long" }).format(wib);
}

function storageKey() {
  return `absensi-${getDateKey(getWIBDate())}`;
}

function getRecords() {
  try {
    return JSON.parse(localStorage.getItem(storageKey())) || [];
  } catch {
    return [];
  }
}

function saveRecords(records) {
  localStorage.setItem(storageKey(), JSON.stringify(records));
}

function renderRecords() {
  const records = getRecords();
  jumlah.textContent = `${records.length} siswa tercatat`;

  if (!records.length) {
    daftar.innerHTML = `<div class="empty">Belum ada absensi hari ini.</div>`;
    return;
  }

  daftar.innerHTML = records.map((r, index) => `
    <div class="record">
      <div class="record-left">
        <div class="avatar">${escapeHTML(r.nama.charAt(0).toUpperCase())}</div>
        <div>
          <div class="name">${escapeHTML(r.nama)}</div>
          <div class="time">Dikirim ${escapeHTML(r.waktu)} WIB</div>
        </div>
      </div>
      <div class="status ${escapeHTML(r.status)}">${statusIcon(r.status)} ${escapeHTML(r.status)}</div>
    </div>
  `).join("");
}

function statusIcon(status) {
  return {
    Hadir: "✅",
    Izin: "🟡",
    Sakit: "🔵",
    Alpa: "🔴"
  }[status] || "📌";
}

function escapeHTML(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

kirimBtn.addEventListener("click", () => {
  const nama = namaInput.value.trim();

  if (!nama) {
    showMessage("⚠️ Nama harus diisi.", true);
    namaInput.focus();
    return;
  }

  if (!selectedStatus) {
    showMessage("⚠️ Pilih status kehadiran terlebih dahulu.", true);
    return;
  }

  const wib = getWIBDate();
  const records = getRecords();

  // Satu nama hanya boleh mengirim sekali pada tanggal yang sama.
  const sudahAda = records.some(r => r.nama.toLowerCase() === nama.toLowerCase());
  if (sudahAda) {
    showMessage("⚠️ Nama tersebut sudah melakukan absensi hari ini.", true);
    return;
  }

  records.push({
    nama,
    status: selectedStatus,
    waktu: `${pad(wib.getHours())}:${pad(wib.getMinutes())}:${pad(wib.getSeconds())}`,
    tanggal: getDateKey(wib)
  });

  saveRecords(records);
  renderRecords();

  namaInput.value = "";
  selectedStatus = null;
  statusButtons.forEach(b => b.classList.remove("selected"));
  showMessage("✅ Absensi berhasil dikirim!", false);
});

hapusBtn.addEventListener("click", () => {
  if (!getRecords().length) return;

  if (confirm("Hapus semua data absensi hari ini dari perangkat ini?")) {
    localStorage.removeItem(storageKey());
    renderRecords();
    showMessage("🗑️ Data hari ini sudah dihapus.", false);
  }
});

function showMessage(text, error) {
  message.textContent = text;
  message.style.color = error ? "#b42318" : "#087f5b";
  setTimeout(() => {
    if (message.textContent === text) message.textContent = "";
  }, 3500);
}

updateClock();
renderRecords();
setInterval(() => {
  const oldKey = storageKey();
  updateClock();
  // Saat WIB melewati 00:00, otomatis pindah ke tanggal baru.
  if (oldKey !== storageKey()) renderRecords();
}, 1000);
