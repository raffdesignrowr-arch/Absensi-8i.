# Absensi Siswa

Fitur:
- Siswa mengisi nama sendiri.
- Pilihan Hadir, Izin, Sakit, dan Alpa.
- Tanggal otomatis mengikuti WIB (UTC+7).
- Jam, menit, dan detik pengiriman dicatat otomatis.
- Tanggal otomatis berganti saat pukul 00:00 WIB.
- Data per tanggal tersimpan di localStorage browser.
- Satu nama hanya dapat mengirim sekali per hari pada browser/perangkat yang sama.
- Tampilan responsif untuk HP dan komputer.

Cara menjalankan:
1. Ekstrak ZIP.
2. Buka `index.html` di browser.
3. Tidak perlu server untuk versi sederhana ini.

Catatan:
Versi ini menyimpan data hanya di browser masing-masing. Jadi jika banyak siswa memakai HP berbeda, data mereka tidak otomatis terkumpul menjadi satu. Untuk absensi kelas sungguhan yang datanya terkumpul ke guru, diperlukan backend/database (misalnya Firebase, Supabase, atau server sendiri).
